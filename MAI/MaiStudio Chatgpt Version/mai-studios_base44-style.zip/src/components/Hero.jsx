import React from 'react';
import { Link } from 'react-router-dom';
import { Sparkles, Flame, Film } from 'lucide-react';

const Hero = () => {
  return (
    <section className="relative w-full h-screen overflow-hidden -mt-20 pt-20">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1920&h=1080&fit=crop"
          alt="Cinema Hero"
          className="absolute inset-0 w-full h-full object-cover"
        />
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/50" />
      </div>

      {/* Hero Content */}
      <div className="relative z-10 h-full flex flex-col justify-center">
        <div className="w-full max-w-7xl mx-auto px-4 md:px-8">
          <div className="max-w-2xl">
            {/* Welcome Label */}
            <div className="flex items-center gap-2 mb-6">
              <Sparkles className="w-6 h-6 text-[#FFD700]" />
              <span className="text-[#FFD700] font-bold tracking-widest text-lg">WELCOME TO</span>
            </div>

            {/* Main Title */}
            <h1 className="text-6xl md:text-8xl font-black mb-6 leading-tight">
              <span className="neon-gold block">MAI</span>
              <span className="neon-red block">Studios</span>
            </h1>

            {/* Subtitle */}
            <p className="text-base md:text-xl text-gray-200 mb-10 leading-relaxed max-w-xl">
              The next generation streaming platform. Watch exclusive shorts and movies, support your favorite creators with MAI Coins.
            </p>

            {/* Buttons */}
            <div className="flex flex-wrap gap-4">
              <Link to="/shorts">
                <button className="neon-btn-red text-white px-8 py-4 text-base md:text-lg font-bold rounded-lg flex items-center gap-2 hover:scale-105 transition-transform duration-300">
                  <Flame className="w-5 h-5" />
                  Watch Shorts
                </button>
              </Link>
              <Link to="/movies">
                <button className="border-2 border-[#FFD700] text-white bg-transparent hover:bg-[#FFD700]/20 px-8 py-4 text-base md:text-lg font-bold rounded-lg flex items-center gap-2 transition-all duration-300">
                  <Film className="w-5 h-5" />
                  Browse Movies
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
