import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { getCurrentUser, signOut } from '../services/authService';
import {
  Home,
  Play,
  Film,
  Coins,
  User,
  Upload,
  Menu,
  X,
  LogOut,
  Shield,
  TrendingUp,
  Sparkles,
  MessageCircle,
  Crown
} from 'lucide-react';

export default function Layout({ children, currentPageName }) {
  const [user, setUser] = useState(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  const loadUser = async () => {
    try {
      const userData = await getCurrentUser();
      if (userData) {
        // Fetch additional profile data if needed
        setUser({
          id: userData.id,
          email: userData.email,
          coin_balance: 0, // TODO: fetch from database
          is_creator: false, // TODO: fetch from database
          role: 'user' // TODO: fetch from database
        });
      } else {
        setUser(null);
      }
    } catch {
      setUser(null);
    }
  };

  useEffect(() => {
    const fetchUser = async () => {
      await loadUser();
    };
    fetchUser();
  }, []);

  const handleLogout = async () => {
    await signOut();
    setUser(null);
    navigate('/');
  };

  const navItems = [
    { name: 'Home', path: '/', icon: Home },
    { name: 'Shorts', path: '/shorts', icon: Play },
    { name: 'Movies', path: '/content', icon: Film },
    { name: 'Coin Store', path: '/coin-store', icon: Coins },
    { name: 'Leaderboard', path: '/leaderboard', icon: TrendingUp },
  ];

  const userNavItems = user ? [
    { name: 'My Profile', path: '/profile', icon: User },
    { name: 'Messages', path: '/messages', icon: MessageCircle },
    ...(user.is_creator ? [{ name: 'Upload', path: '/upload', icon: Upload }] : []),
    ...(user.is_creator ? [{ name: 'Creator Dashboard', path: '/creator-dashboard', icon: TrendingUp }] : []),
    ...(user.is_creator ? [{ name: 'Manage VIP', path: '/manage-vip', icon: Crown }] : []),
    ...(user.role === 'admin' ? [{ name: 'Admin', path: '/admin', icon: Shield }] : []),
  ] : [];

  if (currentPageName === 'TermsAgreement') {
    return (
      <div className="min-h-screen bg-black">
        <style>{`
          :root {
            --neon-gold: #FFD700;
            --neon-gold-glow: rgba(255, 215, 0, 0.5);
            --neon-red: #FF1744;
            --neon-red-glow: rgba(255, 23, 68, 0.5);
          }
        `}</style>
        {children}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <style>{`
        :root {
          --neon-gold: #FFD700;
          --neon-gold-glow: rgba(255, 215, 0, 0.5);
          --neon-red: #FF1744;
          --neon-red-glow: rgba(255, 23, 68, 0.5);
        }
        .neon-gold {
          color: #FFD700;
          text-shadow: 0 0 10px rgba(255, 215, 0, 0.8), 0 0 20px rgba(255, 215, 0, 0.6), 0 0 30px rgba(255, 215, 0, 0.4);
        }
        .neon-red {
          color: #FF1744;
          text-shadow: 0 0 10px rgba(255, 23, 68, 0.8), 0 0 20px rgba(255, 23, 68, 0.6), 0 0 30px rgba(255, 23, 68, 0.4);
        }
        .neon-border-gold {
          border-color: #FFD700;
          box-shadow: 0 0 10px rgba(255, 215, 0, 0.5), inset 0 0 10px rgba(255, 215, 0, 0.1);
        }
        .neon-border-red {
          border-color: #FF1744;
          box-shadow: 0 0 10px rgba(255, 23, 68, 0.5), inset 0 0 10px rgba(255, 23, 68, 0.1);
        }
        .neon-btn-gold {
          background: linear-gradient(135deg, #FFD700 0%, #FFA500 100%);
          box-shadow: 0 0 20px rgba(255, 215, 0, 0.5);
        }
        .neon-btn-gold:hover {
          box-shadow: 0 0 30px rgba(255, 215, 0, 0.8);
        }
        .neon-btn-red {
          background: linear-gradient(135deg, #FF1744 0%, #D50000 100%);
          box-shadow: 0 0 20px rgba(255, 23, 68, 0.5);
        }
        .neon-btn-red:hover {
          box-shadow: 0 0 30px rgba(255, 23, 68, 0.8);
        }
        .card-glow {
          background: linear-gradient(145deg, rgba(30, 30, 30, 0.9), rgba(20, 20, 20, 0.95));
          border: 1px solid rgba(255, 215, 0, 0.2);
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
        }
        .card-glow:hover {
          border-color: rgba(255, 215, 0, 0.5);
          box-shadow: 0 8px 30px rgba(255, 215, 0, 0.2);
        }
      `}</style>

      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-black/90 backdrop-blur-lg border-b border-[#FFD700]/20">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <Sparkles className="w-8 h-8 text-[#FFD700]" />
            <span className="text-2xl font-bold neon-gold tracking-wider">MAI Studios</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-all duration-300 ${
                  window.location.pathname === item.path
                    ? "text-[#FFD700] bg-[#FFD700]/10"
                    : "text-gray-400 hover:text-[#FFD700] hover:bg-[#FFD700]/5"
                }`}
              >
                <item.icon className="w-4 h-4" />
                <span>{item.name}</span>
              </Link>
            ))}
          </nav>

          {/* User Section */}
          <div className="hidden md:flex items-center gap-4">
            {user ? (
              <>
                <div className="flex items-center gap-2 px-4 py-2 rounded-full border border-[#FFD700]/30 bg-[#FFD700]/5">
                  <Coins className="w-4 h-4 text-[#FFD700]" />
                  <span className="text-[#FFD700] font-semibold">{user.coin_balance || 0}</span>
                </div>
                {userNavItems.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    className={`p-2 rounded-lg transition-all duration-300 ${
                      window.location.pathname === item.path
                        ? "text-[#FFD700] bg-[#FFD700]/10"
                        : "text-gray-400 hover:text-[#FFD700]"
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                  </Link>
                ))}
                <button
                  onClick={handleLogout}
                  className="p-2 rounded-lg text-gray-400 hover:text-[#FF1744] transition-all duration-300"
                >
                  <LogOut className="w-5 h-5" />
                </button>
              </>
            ) : (
              <button
                onClick={() => navigate('/login')}
                className="neon-btn-gold text-black font-semibold px-6 py-2 rounded-lg"
              >
                Sign In
              </button>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-[#FFD700]"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden bg-black/95 border-t border-[#FFD700]/20 py-4 px-4">
            {user && (
              <div className="flex items-center gap-2 px-4 py-3 mb-4 rounded-lg border border-[#FFD700]/30 bg-[#FFD700]/5">
                <Coins className="w-5 h-5 text-[#FFD700]" />
                <span className="text-[#FFD700] font-semibold">{user.coin_balance || 0} MAI Coins</span>
              </div>
            )}
            <nav className="space-y-2">
              {[...navItems, ...userNavItems].map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMenuOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    window.location.pathname === item.path
                      ? "text-[#FFD700] bg-[#FFD700]/10"
                      : "text-gray-400 hover:text-[#FFD700]"
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  <span>{item.name}</span>
                </Link>
              ))}
              {user ? (
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg text-[#FF1744] hover:bg-[#FF1744]/10 w-full"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Sign Out</span>
                </button>
              ) : (
                <button
                  onClick={() => navigate('/login')}
                  className="w-full neon-btn-gold text-black font-semibold mt-4 py-3 rounded-lg"
                >
                  Sign In
                </button>
              )}
            </nav>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="pt-20 min-h-screen">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-black border-t border-[#FFD700]/20 py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-[#FFD700]" />
              <span className="text-lg font-bold neon-gold">MAI Studios</span>
            </div>
            <div className="flex gap-6 text-sm text-gray-500">
              <Link to="/policies" className="hover:text-[#FFD700] transition-colors">Policies</Link>
              <Link to="/terms" className="hover:text-[#FFD700] transition-colors">Terms of Use</Link>
              <Link to="/become-creator" className="hover:text-[#FF1744] transition-colors">Become a Creator</Link>
            </div>
          </div>
          <p className="text-center text-gray-600 text-sm mt-6">© 2025 MAI Studios. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}