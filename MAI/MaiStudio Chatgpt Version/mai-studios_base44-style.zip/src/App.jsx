import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Shorts from './pages/Shorts'
import Movies from './pages/Movies'
import Watch from './pages/Watch'
import ContentBrowsing from './pages/ContentBrowsing'
import AdminPanel from './pages/AdminPanel'
import UserProfile from './components/UserProfile'
import Login from './components/Login'
import EditVideo from './pages/EditVideo'
import './App.css'

function AppContent() {
  const location = useLocation();
  const currentPageName = location.pathname.split('/')[1] || 'Home';

  return (
    <Layout currentPageName={currentPageName}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/shorts" element={<Shorts />} />
        <Route path="/movies" element={<Movies />} />
        <Route path="/watch" element={<Watch />} />
        <Route path="/content" element={<ContentBrowsing />} />
        <Route path="/profile" element={<UserProfile />} />
        <Route path="/admin" element={<AdminPanel />} />
        <Route path="/login" element={<Login />} />
        <Route path="/EditVideo" element={<EditVideo />} />
      </Routes>
    </Layout>
  );
}

function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

export default App
