import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import { TrendingUp, Film, Sparkles, ChevronRight } from 'lucide-react';
import Hero from '../components/Hero';
import VideoCard from '../components/video/VideoCard';
import ShortCard from '../components/video/ShortCard';

const Home = () => {
  const { data: featuredVideos = [], isLoading: loadingFeatured } = useQuery({
    queryKey: ['featured-videos'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .eq('status', 'approved')
        .eq('featured', true)
        .order('created_at', { ascending: false })
        .limit(6);
      if (error) throw error;
      return data;
    },
  });

  const { data: trendingShorts = [], isLoading: loadingShorts } = useQuery({
    queryKey: ['trending-shorts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .eq('status', 'approved')
        .eq('content_type', 'short')
        .order('views', { ascending: false })
        .limit(8);
      if (error) throw error;
      return data;
    },
  });

  const { data: latestMovies = [], isLoading: loadingMovies } = useQuery({
    queryKey: ['latest-movies'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .eq('status', 'approved')
        .eq('content_type', 'movie')
        .order('created_at', { ascending: false })
        .limit(6);
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="w-full">
      {/* Hero Component */}
      <Hero />

      {/* Featured Content */}
      <section className="w-full py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-1 h-8 bg-[#FFD700] rounded-full" />
              <h2 className="text-2xl md:text-3xl font-bold text-white">Featured Content</h2>
            </div>
            <Link to="/content" className="flex items-center gap-1 text-[#FFD700] hover:underline">
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          {loadingFeatured ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="aspect-video rounded-xl bg-gray-800/50 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredVideos.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Trending Shorts */}
      <section className="w-full py-16 px-4 bg-gradient-to-b from-transparent via-[#FF1744]/5 to-transparent">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-1 h-8 bg-[#FF1744] rounded-full" />
              <h2 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-6 h-6 text-[#FF1744]" />
                Trending Shorts
              </h2>
            </div>
            <Link to="/content" className="flex items-center gap-1 text-[#FF1744] hover:underline">
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          {loadingShorts ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="aspect-[9/16] rounded-xl bg-gray-800/50 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
              {trendingShorts.map((video) => (
                <ShortCard key={video.id} video={video} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Latest Movies */}
      <section className="w-full py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="w-1 h-8 bg-[#FFD700] rounded-full" />
              <h2 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-2">
                <Film className="w-6 h-6 text-[#FFD700]" />
                Latest Movies
              </h2>
            </div>
            <Link to="/content" className="flex items-center gap-1 text-[#FFD700] hover:underline">
              View All <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          {loadingMovies ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="aspect-video rounded-xl bg-gray-800/50 animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {latestMovies.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="p-12 rounded-3xl border border-[#FFD700]/30 bg-gradient-to-br from-[#FFD700]/10 to-transparent">
            <Sparkles className="w-12 h-12 text-[#FFD700] mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Ready to Create?
            </h2>
            <p className="text-gray-400 mb-8 max-w-lg mx-auto">
              Join MAI Studios as a creator and start earning MAI Coins from your content.
              Cash out your earnings every Monday and Friday.
            </p>
            <Link to="/become-creator">
              <button className="neon-btn-gold text-black px-10 py-6 text-lg font-semibold rounded-lg">
                Apply to Become a Creator
              </button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;