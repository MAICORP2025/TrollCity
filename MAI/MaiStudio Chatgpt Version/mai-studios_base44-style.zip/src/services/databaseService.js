import { supabase } from '../lib/supabase'

export const fetchUserProfile = async (userId) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .single()
  return { data, error }
}

export const updateUserProfile = async (userId, updates) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
  return { data, error }
}

export const fetchVideos = async () => {
  const { data, error } = await supabase
    .from('videos')
    .select('*')
  return { data, error }
}

export const fetchVideoById = async (id) => {
  const { data, error } = await supabase
    .from('videos')
    .select('*')
    .eq('id', id)
    .single()
  return { data, error }
}

export const updateVideo = async (id, updates) => {
  const { data, error } = await supabase
    .from('videos')
    .update(updates)
    .eq('id', id)
    .select()
    .single()
  return { data, error }
}

export const deleteVideo = async (id) => {
  const { error } = await supabase
    .from('videos')
    .delete()
    .eq('id', id)
  return { error }
}

export const createCoinTransaction = async (transaction) => {
  const transactionData = { ...transaction, status: transaction.status || 'completed' }
  const { data, error } = await supabase
    .from('coin_transactions')
    .insert(transactionData)
    .select()
    .single()
  return { data, error }
}

export const fetchCoinTransactions = async (userEmail) => {
  const { data, error } = await supabase
    .from('coin_transactions')
    .select('*')
    .eq('user_email', userEmail)
    .order('created_at', { ascending: false })
  return { data, error }
}

export const fetchAllCoinTransactions = async () => {
  const { data, error } = await supabase
    .from('coin_transactions')
    .select('*')
    .order('created_at', { ascending: false })
  return { data, error }
}

export const updateCoinTransactionStatus = async (id, status) => {
  const { data, error } = await supabase
    .from('coin_transactions')
    .update({ status })
    .eq('id', id)
    .select()
    .single()
  return { data, error }
}

// Add more functions as needed for coins, etc.