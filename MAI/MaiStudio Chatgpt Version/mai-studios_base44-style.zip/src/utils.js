export const createPageUrl = (path) => {
  return path;
};