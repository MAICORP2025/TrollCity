import { supabase } from '../lib/supabase';
import { getCurrentUser } from '../services/authService';

const base44 = {
  auth: {
    async me() {
      try {
        const userData = await getCurrentUser();
        if (userData) {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', userData.id)
            .single();
          return { ...userData, ...profile };
        }
        return null;
      } catch {
        return null;
      }
    },
    async updateMe(data) {
      const user = await getCurrentUser();
      if (!user) throw new Error('Not authenticated');
      const { error } = await supabase
        .from('profiles')
        .update(data)
        .eq('id', user.id);
      if (error) throw error;
    },
    redirectToLogin() {
      window.location.href = '/login';
    }
  },
  entities: {
    Video: {
      async filter(query, sort = '', limit = null) {
        let qb = supabase.from('videos').select('*');
        if (query) {
          Object.entries(query).forEach(([key, value]) => {
            if (key === 'neq') {
              qb = qb.neq(value.field, value.value);
            } else {
              qb = qb.eq(key, value);
            }
          });
        }
        if (sort) {
          if (sort.startsWith('-')) {
            qb = qb.order(sort.slice(1), { ascending: false });
          } else {
            qb = qb.order(sort, { ascending: true });
          }
        }
        if (limit) {
          qb = qb.limit(limit);
        }
        const { data, error } = await qb;
        if (error) throw error;
        return data;
      },
      async update(id, data) {
        const { error } = await supabase
          .from('videos')
          .update(data)
          .eq('id', id);
        if (error) throw error;
      }
    },
    UnlockedContent: {
      async filter(query) {
        let qb = supabase.from('unlocked_content').select('*');
        if (query) {
          Object.entries(query).forEach(([key, value]) => {
            qb = qb.eq(key, value);
          });
        }
        const { data, error } = await qb;
        if (error) throw error;
        return data;
      },
      async create(data) {
        const { error } = await supabase
          .from('unlocked_content')
          .insert(data);
        if (error) throw error;
      }
    },
    CoinTransaction: {
      async filter(query, sort = '', limit = null) {
        let qb = supabase.from('coin_transactions').select('*');
        if (query) {
          Object.entries(query).forEach(([key, value]) => {
            if (key === 'neq') {
              qb = qb.neq(value.field, value.value);
            } else {
              qb = qb.eq(key, value);
            }
          });
        }
        if (sort) {
          if (sort.startsWith('-')) {
            qb = qb.order(sort.slice(1), { ascending: false });
          } else {
            qb = qb.order(sort, { ascending: true });
          }
        }
        if (limit) {
          qb = qb.limit(limit);
        }
        const { data, error } = await qb;
        if (error) throw error;
        return data;
      },
      async create(data) {
        const { error } = await supabase
          .from('coin_transactions')
          .insert(data);
        if (error) throw error;
      }
    }
  }
};

export { base44 };